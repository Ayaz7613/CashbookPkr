# Cashbook PKR — Android starter app

A simple native Android cashbook for tracking cash income and expenses in Pakistani rupees.

## Features
- Add money-in and money-out transactions
- Automatically calculated all-time cash balance
- Today's totals
- Recent transactions and full history
- Delete a transaction
- Simple reports screen
- Saves data locally on the phone using SharedPreferences; no account or internet connection is required

## Build and install
1. Install **Android Studio** on a computer: https://developer.android.com/studio
2. Extract this ZIP file.
3. In Android Studio choose **Open** and select the extracted `CashbookPKR` folder.
4. Allow Gradle sync to finish. If prompted, install Android SDK Platform 35.
5. Connect your Android phone with USB debugging enabled, or create an emulator.
6. Press **Run ▶** to build and install the app.
7. To create an APK: **Build → Build Bundle(s) / APK(s) → Build APK(s)**. Android Studio will show the APK location.

## Important notes
- This starter stores transactions locally on this phone. Uninstalling the app or clearing its data can erase records, so keep independent records until backup/export is added.
- Balance is total recorded income minus total recorded expenses. Enter your opening cash as a Money In transaction if you want the starting cash included.
- Dates are set from the phone's current date.
- This is starter source code, not a prebuilt APK. You need Android Studio to compile it.
