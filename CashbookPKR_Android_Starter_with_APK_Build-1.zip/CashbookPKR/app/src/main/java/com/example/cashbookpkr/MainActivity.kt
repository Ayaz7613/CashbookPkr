package com.example.cashbookpkr

import android.os.Bundle
import android.content.Context
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class Entry(val id: Long, val type: String, val amount: Long, val note: String, val date: String)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme { CashbookApp(this) } }
    }
}

private fun money(n: Long) = "Rs. " + String.format(Locale.US, "%,d", n)
private fun today() = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())

@Composable
fun CashbookApp(context: Context) {
    val prefs = remember { context.getSharedPreferences("cashbook", Context.MODE_PRIVATE) }
    fun load(): List<Entry> {
        val arr = try { JSONArray(prefs.getString("entries", "[]")) } catch (_: Exception) { JSONArray() }
        return (0 until arr.length()).mapNotNull { i ->
            try {
                val o = arr.getJSONObject(i)
                Entry(o.getLong("id"), o.getString("type"), o.getLong("amount"), o.getString("note"), o.getString("date"))
            } catch (_: Exception) { null }
        }.sortedByDescending { it.id }
    }
    var entries by remember { mutableStateOf(load()) }
    var type by remember { mutableStateOf("INCOME") }
    var amountText by remember { mutableStateOf("") }
    var note by remember { mutableStateOf("") }
    var selectedTab by remember { mutableStateOf("HOME") }
    var message by remember { mutableStateOf("") }

    fun save(list: List<Entry>) {
        val arr = JSONArray()
        list.forEach { e ->
            arr.put(JSONObject().put("id", e.id).put("type", e.type).put("amount", e.amount)
                .put("note", e.note).put("date", e.date))
        }
        prefs.edit().putString("entries", arr.toString()).apply()
        entries = list.sortedByDescending { it.id }
    }

    val income = entries.filter { it.type == "INCOME" }.sumOf { it.amount }
    val expense = entries.filter { it.type == "EXPENSE" }.sumOf { it.amount }
    val todayEntries = entries.filter { it.date == today() }
    val todayIn = todayEntries.filter { it.type == "INCOME" }.sumOf { it.amount }
    val todayOut = todayEntries.filter { it.type == "EXPENSE" }.sumOf { it.amount }

    Scaffold(
        topBar = { TopAppBarCompat(title = "Cashbook PKR") },
        bottomBar = {
            NavigationBar {
                listOf("HOME" to "Home", "HISTORY" to "History", "REPORTS" to "Reports").forEach { (key, label) ->
                    NavigationBarItem(selected = selectedTab == key, onClick = { selectedTab = key },
                        icon = {}, label = { Text(label) })
                }
            }
        }
    ) { pad ->
        LazyColumn(Modifier.fillMaxSize().padding(pad).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            when (selectedTab) {
                "HOME" -> {
                    item {
                        Card(Modifier.fillMaxWidth()) {
                            Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                Text("CURRENT CASH BALANCE", style = MaterialTheme.typography.labelMedium)
                                Text(money(income - expense), style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
                                Text("All-time income minus all-time expenses")
                            }
                        }
                    }
                    item {
                        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            SummaryCard("Total money in", money(income), Modifier.weight(1f))
                            SummaryCard("Total money out", money(expense), Modifier.weight(1f))
                        }
                    }
                    item { Text("Add transaction", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold) }
                    item {
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            FilterChip(selected = type == "INCOME", onClick = { type = "INCOME" }, label = { Text("Money In") })
                            FilterChip(selected = type == "EXPENSE", onClick = { type = "EXPENSE" }, label = { Text("Money Out") })
                        }
                    }
                    item {
                        OutlinedTextField(value = amountText, onValueChange = { amountText = it.filter { c -> c.isDigit() } },
                            label = { Text("Amount (PKR)") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            modifier = Modifier.fillMaxWidth(), singleLine = true)
                    }
                    item {
                        OutlinedTextField(value = note, onValueChange = { note = it }, label = { Text("Note (optional)") },
                            modifier = Modifier.fillMaxWidth(), singleLine = true)
                    }
                    item {
                        Button(onClick = {
                            val amount = amountText.toLongOrNull()
                            if (amount == null || amount <= 0L) message = "Enter an amount greater than zero."
                            else {
                                save(entries + Entry(System.currentTimeMillis(), type, amount, note.trim(), today()))
                                amountText = ""; note = ""; message = "Transaction saved."
                            }
                        }, modifier = Modifier.fillMaxWidth()) { Text(if (type == "INCOME") "Save Money In" else "Save Money Out") }
                    }
                    if (message.isNotBlank()) item { Text(message, color = MaterialTheme.colorScheme.primary) }
                    item { Text("Today's activity", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold) }
                    item { Text("Received: ${money(todayIn)}    Paid: ${money(todayOut)}") }
                    item { Text("Recent transactions", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold) }
                    items(entries.take(5), key = { it.id }) { e -> EntryRow(e) }
                    if (entries.isEmpty()) item { Text("No transactions yet. Add your first entry above.") }
                }
                "HISTORY" -> {
                    item { Text("Transaction history", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold) }
                    if (entries.isEmpty()) item { Text("No transactions recorded yet.") }
                    items(entries, key = { it.id }) { e ->
                        EntryRow(e)
                        TextButton(onClick = { save(entries.filterNot { it.id == e.id }) }) { Text("Delete this entry") }
                        HorizontalDivider()
                    }
                }
                else -> {
                    item { Text("Reports", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold) }
                    item { SummaryCard("All-time income", money(income), Modifier.fillMaxWidth()) }
                    item { SummaryCard("All-time expenses", money(expense), Modifier.fillMaxWidth()) }
                    item { SummaryCard("Current balance", money(income - expense), Modifier.fillMaxWidth()) }
                    item { HorizontalDivider() }
                    item { Text("Today's report (${today()})", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold) }
                    item { Text("Money received: ${money(todayIn)}") }
                    item { Text("Money paid: ${money(todayOut)}") }
                    item { Text("Net change today: ${money(todayIn - todayOut)}") }
                    item { Text("Monthly reports and export/backup can be added in a later version.") }
                }
            }
        }
    }
}

@Composable
private fun TopAppBarCompat(title: String) {
    Surface(tonalElevation = 2.dp) {
        Text(title, modifier = Modifier.fillMaxWidth().padding(18.dp), style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun SummaryCard(title: String, value: String, modifier: Modifier = Modifier) {
    Card(modifier) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text(title, style = MaterialTheme.typography.labelMedium)
            Text(value, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
private fun EntryRow(e: Entry) {
    Row(Modifier.fillMaxWidth().padding(vertical = 8.dp), horizontalArrangement = Arrangement.SpaceBetween) {
        Column(Modifier.weight(1f)) {
            Text(if (e.note.isBlank()) if (e.type == "INCOME") "Money received" else "Money paid" else e.note,
                fontWeight = FontWeight.SemiBold)
            Text(e.date, style = MaterialTheme.typography.bodySmall)
        }
        Text((if (e.type == "INCOME") "+ " else "− ") + money(e.amount),
            color = if (e.type == "INCOME") MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error,
            fontWeight = FontWeight.Bold)
    }
}
